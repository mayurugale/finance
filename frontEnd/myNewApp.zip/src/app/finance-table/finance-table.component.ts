import { getLocaleDayNames } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CommonService } from '../common/common.service';



@Component({
  selector: 'app-finance-table',
  templateUrl: './finance-table.component.html',
  styleUrls: ['./finance-table.component.css']
})
export class FinanceTableComponent implements OnInit {
  displayedColumns: string[] = ['id', 'name', 'address', 'pin_code'];
  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) 
  paginator!: MatPaginator;
  @ViewChild(MatSort)
   sort!: MatSort;

  constructor(public common:CommonService) { 
  this.common.userdata().subscribe((users:any)=>{
    this.dataSource = new MatTableDataSource(users);

    console.log(users)
  })
  }
  ngOnInit(): void {
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}

 


